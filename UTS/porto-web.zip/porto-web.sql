-- --------------------------------------------------------
-- Host:                         localhost
-- Server version:               5.7.24 - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             10.2.0.5599
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for table porto-web.about
CREATE TABLE IF NOT EXISTS `about` (
  `id_par` int(11) NOT NULL,
  `isi_par` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id_par`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table porto-web.about: ~3 rows (approximately)
/*!40000 ALTER TABLE `about` DISABLE KEYS */;
INSERT INTO `about` (`id_par`, `isi_par`) VALUES
	(1, 'An informatics student who likes photography and is looking for freelance work opportunities.'),
	(2, 'I started photography since junior high school, but when I was in high school I majored in software engineering because I also liked technology.'),
	(3, 'Back in the informatics department at college didn\'t make me forget my hobby.'),
	(4, 'If you want to work with me, you can send me an email and discuss the project. You can also find me on my social media.');
/*!40000 ALTER TABLE `about` ENABLE KEYS */;

-- Dumping structure for table porto-web.art
CREATE TABLE IF NOT EXISTS `art` (
  `id` int(11) NOT NULL,
  `image_name` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table porto-web.art: ~3 rows (approximately)
/*!40000 ALTER TABLE `art` DISABLE KEYS */;
INSERT INTO `art` (`id`, `image_name`) VALUES
	(1, 'art-1.jpeg'),
	(2, 'art-2.jpeg'),
	(3, 'art-3.jpeg');
/*!40000 ALTER TABLE `art` ENABLE KEYS */;

-- Dumping structure for table porto-web.contact
CREATE TABLE IF NOT EXISTS `contact` (
  `id_contact` int(11) NOT NULL,
  `nama_tempat` varchar(100) DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_contact`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table porto-web.contact: ~0 rows (approximately)
/*!40000 ALTER TABLE `contact` DISABLE KEYS */;
INSERT INTO `contact` (`id_contact`, `nama_tempat`, `alamat`) VALUES
	(1, 'Universitas Pembangunan Jaya', 'Jalan Cendrawasih Raya Blok B7/P, Sawah Baru, Kec. Ciputat, Kota Tangerang Selatan, Banten 15413');
/*!40000 ALTER TABLE `contact` ENABLE KEYS */;

-- Dumping structure for table porto-web.contactpersonal
CREATE TABLE IF NOT EXISTS `contactpersonal` (
  `id_cp` int(11) NOT NULL,
  `nama_cp` varchar(100) DEFAULT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `nomor_cp` varchar(255) DEFAULT NULL,
  `email_cp` varchar(255) DEFAULT NULL,
  `foto_cp` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id_cp`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table porto-web.contactpersonal: ~2 rows (approximately)
/*!40000 ALTER TABLE `contactpersonal` DISABLE KEYS */;
INSERT INTO `contactpersonal` (`id_cp`, `nama_cp`, `keterangan`, `nomor_cp`, `email_cp`, `foto_cp`) VALUES
	(1, 'Anayah Hanifah Elsyaf', 'Pemilik sekaligus pendiri website :3 (Hobinya banyak, fotografi, gambar, ngoding, gabut, rebahan). Tapi tenang aja, hobi yang paling dominan itu hobi menjadi manusia yang bermanfaat di masyarakat :\')', '0812-xxxx-xxxx', 'Anayah.hanifahelsyaf@student.upj.ac.id', 'profil-image.jpeg');
/*!40000 ALTER TABLE `contactpersonal` ENABLE KEYS */;

-- Dumping structure for table porto-web.gallery
CREATE TABLE IF NOT EXISTS `gallery` (
  `id` int(11) NOT NULL,
  `image_name` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table porto-web.gallery: ~4 rows (approximately)
/*!40000 ALTER TABLE `gallery` DISABLE KEYS */;
INSERT INTO `gallery` (`id`, `image_name`) VALUES
	(1, 'fotografi-1.jpeg'),
	(2, 'fotografi-2.jpeg'),
	(3, 'fotografi-3.jpeg'),
	(4, 'profil-image.jpeg');
/*!40000 ALTER TABLE `gallery` ENABLE KEYS */;

-- Dumping structure for table porto-web.introduction
CREATE TABLE IF NOT EXISTS `introduction` (
  `id` int(11) NOT NULL,
  `judul` varchar(50) DEFAULT NULL,
  `isi` varchar(500) DEFAULT NULL,
  `image_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table porto-web.introduction: ~2 rows (approximately)
/*!40000 ALTER TABLE `introduction` DISABLE KEYS */;
INSERT INTO `introduction` (`id`, `judul`, `isi`, `image_name`) VALUES
	(1, 'Anayah Hanifah Elsyaf', 'Seorang mahasiswa dari jurusan Informatika Pembangungan Jaya.\r\nMemiliki banyak hobi, salah satunya membuat website ini ^^', 'profil-image.jpeg'),
	(2, 'Fotografi', 'Salah satu fotografi tekstur', 'fotografi-2.jpeg'),
	(3, 'Art', 'Salah satu gambar menggunakan pensil warna', 'art-3.jpeg'),
	(4, 'Web Desain', 'Salah satu desain web portofolio', 'web-1.jpg');
/*!40000 ALTER TABLE `introduction` ENABLE KEYS */;

-- Dumping structure for table porto-web.message_cust
CREATE TABLE IF NOT EXISTS `message_cust` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(250) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `subject_pesan` varchar(250) DEFAULT NULL,
  `pesan` varchar(250) DEFAULT NULL,
  `waktu` varchar(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table porto-web.message_cust: ~2 rows (approximately)
/*!40000 ALTER TABLE `message_cust` DISABLE KEYS */;
INSERT INTO `message_cust` (`id`, `nama`, `email`, `subject_pesan`, `pesan`, `waktu`) VALUES
	(1, 'Anayah', 'anayah@gmail.com', 'hello', 'asdf', '0'),
	(2, 'Anayah', 'anayah@gmail.com', 'hello', 'hii', '2021-10-19 10:51:44');
/*!40000 ALTER TABLE `message_cust` ENABLE KEYS */;

-- Dumping structure for table porto-web.sosmed
CREATE TABLE IF NOT EXISTS `sosmed` (
  `id_sosmed` int(11) NOT NULL,
  `nama_sosmed` varchar(50) DEFAULT NULL,
  `link_sosmed` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id_sosmed`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table porto-web.sosmed: ~4 rows (approximately)
/*!40000 ALTER TABLE `sosmed` DISABLE KEYS */;
INSERT INTO `sosmed` (`id_sosmed`, `nama_sosmed`, `link_sosmed`) VALUES
	(1, 'INSTAGRAM', 'https://www.instagram.com/nayysuw/'),
	(2, 'LINKEDIN', 'https://www.linkedin.com/in/anayah-hanifah-elsyaf-648b3a1a6/'),
	(3, 'GITHUB', 'https://github.com/NayHanif'),
	(4, 'BEHANCE', 'https://www.behance.net/anayahhanifahe'),
	(5, 'VSCO', 'https://vsco.co/hafels/gallery');
/*!40000 ALTER TABLE `sosmed` ENABLE KEYS */;

-- Dumping structure for table porto-web.web
CREATE TABLE IF NOT EXISTS `web` (
  `id` int(11) NOT NULL,
  `image_name` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table porto-web.web: ~3 rows (approximately)
/*!40000 ALTER TABLE `web` DISABLE KEYS */;
INSERT INTO `web` (`id`, `image_name`) VALUES
	(1, 'web-1.jpg'),
	(2, 'web-2.jpg'),
	(3, 'web-3.jpg');
/*!40000 ALTER TABLE `web` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
